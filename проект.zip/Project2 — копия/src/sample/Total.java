package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

class Total{
    int sum = 0;
    FlowPane flowPane;
    Total() throws Exception {
        InterfaceDrink interfaceDrink = new InterfaceDrink();
        InterfacePizza interfacePizza = new InterfacePizza();
        InterfaceBurger interfaceBurger = new InterfaceBurger();
        InterfaceDessert interfaceDessert = new InterfaceDessert();
        Label label = new Label();
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                label.setText("500");
            }
        };
        interfaceBurger.buttonBurger.setOnAction(event);
        interfaceBurger.buttonGumburger.setOnAction(event);
        EventHandler<ActionEvent> event1 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                label.setText("600");
            }
        };
        interfaceBurger.buttonCheese.setOnAction(event1);
        EventHandler<ActionEvent> event2 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                label.setText("700");
            }
        };
        interfaceBurger.buttonBig.setOnAction(event2);
        EventHandler<ActionEvent> event3 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                label.setText("900");
            }
        };
        interfaceBurger.buttonMac.setOnAction(event3);
        EventHandler<ActionEvent> event4 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                label.setText("1100");
            }
        };
        interfaceBurger.buttonChick.setOnAction(event4);
        flowPane = new FlowPane();
        flowPane.getChildren().addAll(label);
        flowPane.setAlignment(Pos.CENTER);
    }

}
