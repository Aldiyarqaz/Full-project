package sample;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.io.FileInputStream;
import java.util.ArrayList;

class InterfaceDessert {
    BorderPane borderPane;
    FlowPane pane;
    Button buttonS1, buttonS2, buttonS3, buttonS4, buttonS5, back;

    InterfaceDessert() throws Exception {

        ArrayList<String> options = new ArrayList<>();

        pane = new FlowPane();
        pane.setPadding(new Insets(30, 12, 13, 30));
        pane.setHgap(30);
        pane.setVgap(30);
        FileInputStream backgrou = new FileInputStream("de.jpg");
        Image imagebackground = new Image(backgrou);
        BackgroundImage bi = new BackgroundImage(imagebackground,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        Background background = new Background(bi);
        FileInputStream fileInputStream = new FileInputStream("s1.png");
        FileInputStream fileInputStream1 = new FileInputStream("s2.png");
        FileInputStream fileInputStream2 = new FileInputStream("s3.png");
        FileInputStream fileInputStream3 = new FileInputStream("s4.png");
        FileInputStream fileInputStream4 = new FileInputStream("s5.png");

        Image image = new Image(fileInputStream);
        Image image1 = new Image(fileInputStream1);
        Image image2 = new Image(fileInputStream2);
        Image image3 = new Image(fileInputStream3);
        Image image4 = new Image(fileInputStream4);


        ImageView imageView = new ImageView(image);
        ImageView imageView1 = new ImageView(image1);
        ImageView imageView2 = new ImageView(image2);
        ImageView imageView3 = new ImageView(image3);
        ImageView imageView4 = new ImageView(image4);


        HBox vBox = new HBox(10);
        borderPane = new BorderPane();

        options.add("300 тг");
        options.add("300 тг");
        options.add("400 тг");
        options.add("400 тг");
        options.add("300 тг");

        borderPane.setBackground(background);
        borderPane.setTop(vBox);
        borderPane.setCenter(pane);
        back = new Button("<-");
        buttonS1 = new Button(options.get(0), imageView);
        buttonS2 = new Button(options.get(1), imageView1);
        buttonS3 = new Button(options.get(2), imageView2);
        buttonS4 = new Button(options.get(3), imageView3);
        buttonS5 = new Button(options.get(4), imageView4);

        vBox.getChildren().addAll(back);
        pane.getChildren().addAll(buttonS1, buttonS2, buttonS3, buttonS4, buttonS5);

    }
}
