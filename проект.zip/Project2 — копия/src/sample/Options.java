package sample;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.FileInputStream;
import java.util.ArrayList;

class Options{
    ArrayList<String> options = new ArrayList<>();
    VBox pane;
    Button btBurger, btPizza, btDrink, btDessert;
    Button back = new Button("Back");
    FileInputStream fileInputStream = new FileInputStream("aaa.JPG");
    Image image = new Image(fileInputStream);
    BackgroundImage bi = new BackgroundImage(image,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            BackgroundSize.DEFAULT);
    Background background = new Background(bi);
    Options() throws Exception{
        pane = new VBox(30);
        pane.setAlignment(Pos.CENTER);
        pane.setBackground(background);
        Label label = new Label("What do you want?");
        label.setFont(Font.font("Times New Roman", FontWeight.BOLD, 30));
        label.setTextFill(Color.WHITE);

        options.add("Burger");
        options.add("Pizza");
        options.add("Drink");
        options.add("Dessert");

        pane.getChildren().add(label);
        btBurger = new Button(options.get(0));
        pane.getChildren().addAll(btBurger);
        btPizza = new Button(options.get(1));
        pane.getChildren().addAll(btPizza);
        btDrink = new Button(options.get(2));
        pane.getChildren().addAll(btDrink);
        btDessert = new Button(options.get(3));
        pane.getChildren().addAll(btDessert);
        btBurger.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
        btPizza.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
        btDrink.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
        btDessert.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));


    }
}
