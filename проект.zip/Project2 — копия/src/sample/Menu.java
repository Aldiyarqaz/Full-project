package sample;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Scanner;

class Menu{
    GridPane gridPane;
    Button login;
    Menu() throws Exception {


        gridPane = new GridPane();
        FileInputStream fileInputStream = new FileInputStream("pizza.jpg");
        Image image = new Image(fileInputStream);
        BackgroundImage bi = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        Background back = new Background(bi);
        gridPane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        gridPane.setHgap(5.5);
        gridPane.setVgap(5.5);
        gridPane.setBackground(back);
        gridPane.setAlignment(Pos.CENTER);
        Label nameLabel = new Label("Welcome to IITU'pizza");

        login = new Button("Log in");
        nameLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 30));
        nameLabel.setTextFill(Color.BLACK);
        TextField textFieldName = new TextField();
        TextField textFieldPassword = new TextField();
        Client client = new Client(textFieldName.getText(), textFieldPassword.getText());
        FileInputStream fileInputStream1 = new FileInputStream("текст.txt");
        Scanner in = new Scanner(fileInputStream1);
        while (in.hasNext()) {
            String[] line = in.nextLine().trim().split(" ");

            try {
                textFieldName.setText(textFieldName.getText());
                textFieldName.setText(textFieldPassword.getText());
                String textName = textFieldName.getText();
                String textPassword = textFieldPassword.getText();
                //String name = client.getName();
                //String password = textPassword;
                Connection mySql = DriverManager.getConnection("jdbc:mysql://"+line[0]+"/"+line[1], line[2], line[3]);
                Statement mySt = mySql.createStatement();
                ResultSet myRS = mySt.executeQuery("select * from clients");
                String query = " insert into clients (Name, Password)"
                        + " values (?, ?)";
                PreparedStatement myPS = mySql.prepareStatement(query);

                myPS.setString(1, textName);
                myPS.setString(2, textPassword);
                myPS.execute();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            gridPane.add(nameLabel, 1, 0);
            gridPane.add(textFieldName, 1, 2);
            gridPane.add(textFieldPassword, 1, 3);
            gridPane.add(login, 1, 4);
        }
    }
}
