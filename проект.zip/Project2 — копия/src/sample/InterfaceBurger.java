package sample;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.io.FileInputStream;
import java.util.ArrayList;

class InterfaceBurger{
    BorderPane borderPane;
    FlowPane pane;
    Button buttonBurger, buttonCheese, buttonGumburger, buttonBig, buttonMac, buttonChick, back;
    ArrayList<String> options = new ArrayList<>();
    InterfaceBurger() throws Exception{
        pane = new FlowPane();
        pane.setPadding(new Insets(30,12,13,30));
        pane.setHgap(10);
        pane.setVgap(30);
        FileInputStream backgrou = new FileInputStream("b2.jpg");
        Image imageback = new Image(backgrou);
        BackgroundImage bi = new BackgroundImage(imageback,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        Background background = new Background(bi);
        FileInputStream fileInputStream = new FileInputStream("1.png");
        FileInputStream fileInputStream1 = new FileInputStream("2.png");
        FileInputStream fileInputStream2 = new FileInputStream("3.png");
        FileInputStream fileInputStream3 = new FileInputStream("bur1.png");
        FileInputStream fileInputStream4 = new FileInputStream("big.png");
        FileInputStream fileInputStream5 = new FileInputStream("bur5.png");
        Image image = new Image(fileInputStream);
        Image image1 = new Image(fileInputStream1);
        Image image2 = new Image(fileInputStream2);
        Image image3 = new Image(fileInputStream3);
        Image image4 = new Image(fileInputStream4);
        Image image5 = new Image(fileInputStream5);
        ImageView imageView = new ImageView(image);
        ImageView imageView1 = new ImageView(image1);
        ImageView imageView2 = new ImageView(image2);
        ImageView imageView3 = new ImageView(image3);
        ImageView imageView4 = new ImageView(image4);
        ImageView imageView5 = new ImageView(image5);

        HBox vBox = new HBox();
        borderPane = new BorderPane();

        options.add("500 тг");
        options.add("600 тг");
        options.add("500 тг");
        options.add("700 тг");
        options.add("900 тг");
        options.add("1100 тг");

        borderPane.setBackground(background);
        borderPane.setTop(vBox);
        borderPane.setCenter(pane);
        back = new Button("<-");
        pane.setBackground(background);
        buttonBurger = new Button(options.get(0), imageView);
        buttonCheese = new Button(options.get(1), imageView1);
        buttonGumburger = new Button(options.get(2), imageView2);
        buttonBig = new Button(options.get(3), imageView3);
        buttonMac = new Button(options.get(4),imageView4);
        buttonChick = new Button(options.get(5), imageView5);


        vBox.getChildren().addAll(back);
        pane.getChildren().addAll(buttonBurger, buttonCheese, buttonGumburger,buttonBig, buttonMac, buttonChick);

    }
}
