package sample;

import javafx.application.Application;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import java.awt.*;
import java.io.FileInputStream;


public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Menu menu = new Menu();
        Scene scene = new Scene(menu.gridPane,500,750);

        Options options = new Options();
        Scene sceneOptions = new Scene(options.pane,700,600);

        InterfaceBurger interfaceBurger = new InterfaceBurger();
        Scene sceneBurger = new Scene(interfaceBurger.borderPane, 800, 500);

        Total total = new Total();
        Scene sceneTotal = new Scene(total.flowPane, 500, 500);

        InterfacePizza interfacePizza = new InterfacePizza();
        Scene sceneCombo = new Scene(interfacePizza.borderPane, 560, 540);

        InterfaceDrink interfaceDrink = new InterfaceDrink();
        Scene sceneDrink = new Scene(interfaceDrink.borderPane, 720,550);

        InterfaceDessert interfaceDesert = new InterfaceDessert();
        Scene sceneDessert = new Scene(interfaceDesert.borderPane,734,730);


        menu.login.setOnAction(event -> primaryStage.setScene(sceneOptions));
        options.btBurger.setOnAction(event -> primaryStage.setScene(sceneBurger));
        options.btPizza.setOnAction(event -> primaryStage.setScene(sceneCombo));
        options.btDrink.setOnAction(event -> primaryStage.setScene(sceneDrink));
        options.btDessert.setOnAction(event -> primaryStage.setScene(sceneDessert));
        interfaceDesert.back.setOnAction(event -> primaryStage.setScene(sceneOptions));
        interfaceDrink.back.setOnAction(event -> primaryStage.setScene(sceneOptions));
        interfacePizza.back.setOnAction(event -> primaryStage.setScene(sceneOptions));
        interfaceBurger.back.setOnAction(event -> primaryStage.setScene(sceneOptions));

        FileInputStream fileInputStream = new FileInputStream("fin.jpg");
        javafx.scene.image.Image image = new Image(fileInputStream);
        BackgroundImage bi = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        Background back = new Background(bi);
        FlowPane flowPane = new FlowPane();
        Label label = new Label("Your check: 500 тг");
        label.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane.getChildren().addAll(label);
        flowPane.setAlignment(Pos.CENTER);
        flowPane.setBackground(back);
        interfaceBurger.buttonGumburger.setOnAction(event -> primaryStage.setScene(new Scene(flowPane,450,300)));
        interfaceBurger.buttonBurger.setOnAction(event -> primaryStage.setScene(new Scene(flowPane,450,300)));
        FlowPane flowPane1 = new FlowPane();
        Label label1 = new Label("Your check: 600 тг");
        label1.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane1.getChildren().addAll(label1);
        flowPane1.setAlignment(Pos.CENTER);
        flowPane1.setBackground(back);
        interfaceBurger.buttonCheese.setOnAction(event -> primaryStage.setScene(new Scene(flowPane1,450,300)));
        FlowPane flowPane2 = new FlowPane();
        Label label2 = new Label("Your check: 700 тг");
        label2.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane2.getChildren().addAll(label2);
        flowPane2.setAlignment(Pos.CENTER);
        flowPane2.setBackground(back);
        interfaceBurger.buttonBig.setOnAction(event -> primaryStage.setScene(new Scene(flowPane2,450,300)));
        FlowPane flowPane3 = new FlowPane();
        Label label3 = new Label("Your check: 900 тг");
        label3.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane3.getChildren().addAll(label3);
        flowPane3.setAlignment(Pos.CENTER);
        flowPane3.setBackground(back);
        interfaceBurger.buttonMac.setOnAction(event -> primaryStage.setScene(new Scene(flowPane3,450,300)));
        FlowPane flowPane4 = new FlowPane();
        Label label4 = new Label("Your check: 1100 тг");
        label4.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane4.getChildren().addAll(label4);
        flowPane4.setAlignment(Pos.CENTER);
        flowPane4.setBackground(back);
        interfaceBurger.buttonChick.setOnAction(event -> primaryStage.setScene(new Scene(flowPane4,450,300)));
        FlowPane flowPane5 = new FlowPane();
        Label label5 = new Label("Your check: 1500 тг");
        label5.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane5.getChildren().addAll(label5);
        flowPane5.setAlignment(Pos.CENTER);
        flowPane5.setBackground(back);
        interfacePizza.buttonC1.setOnAction(event -> primaryStage.setScene(new Scene(flowPane5,450,300)));
        interfacePizza.buttonC3.setOnAction(event -> primaryStage.setScene(new Scene(flowPane5,450,300)));
        FlowPane flowPane6 = new FlowPane();
        Label label6 = new Label("Your check: 1600 тг");
        label6.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane6.getChildren().addAll(label6);
        flowPane6.setAlignment(Pos.CENTER);
        flowPane6.setBackground(back);
        interfacePizza.buttonC2.setOnAction(event -> primaryStage.setScene(new Scene(flowPane6,450,300)));
        FlowPane flowPane7 = new FlowPane();
        Label label7 = new Label("Your check: 1700 тг");
        label7.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane7.getChildren().addAll(label7);
        flowPane7.setAlignment(Pos.CENTER);
        flowPane7.setBackground(back);
        interfacePizza.buttonC4.setOnAction(event -> primaryStage.setScene(new Scene(flowPane7,450,300)));
        FlowPane flowPane8 = new FlowPane();
        Label label8 = new Label("Your check: 300 тг");
        label8.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane8.getChildren().addAll(label8);
        flowPane8.setAlignment(Pos.CENTER);
        flowPane8.setBackground(back);
        interfaceDesert.buttonS1.setOnAction(event -> primaryStage.setScene(new Scene(flowPane8,450,300)));
        interfaceDesert.buttonS2.setOnAction(event -> primaryStage.setScene(new Scene(flowPane8,450,300)));
        interfaceDesert.buttonS5.setOnAction(event -> primaryStage.setScene(new Scene(flowPane8,450,300)));
        FlowPane flowPane9 = new FlowPane();
        Label label9 = new Label("Your check: 400 тг");
        label9.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane9.getChildren().addAll(label9);
        flowPane9.setAlignment(Pos.CENTER);
        flowPane9.setBackground(back);
        interfaceDesert.buttonS3.setOnAction(event -> primaryStage.setScene(new Scene(flowPane9,450,300)));
        interfaceDesert.buttonS4.setOnAction(event -> primaryStage.setScene(new Scene(flowPane9,450,300)));
        FlowPane flowPane10 = new FlowPane();
        Label label10 = new Label("Your check: 200 тг");
        label10.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane10.getChildren().addAll(label10);
        flowPane10.setAlignment(Pos.CENTER);
        flowPane10.setBackground(back);
        interfaceDrink.buttonD1.setOnAction(event -> primaryStage.setScene(new Scene(flowPane10,450,300)));
        interfaceDrink.buttonD2.setOnAction(event -> primaryStage.setScene(new Scene(flowPane10,450,300)));
        FlowPane flowPane11 = new FlowPane();
        Label label11 = new Label("Your check: 180 тг");
        label11.setFont(Font.font(null, FontWeight.BOLD,30));
        flowPane11.getChildren().addAll(label11);
        flowPane11.setAlignment(Pos.CENTER);
        flowPane11.setBackground(back);
        interfaceDrink.buttonD3.setOnAction(event -> primaryStage.setScene(new Scene(flowPane11,450,300)));
        interfaceDrink.buttonD4.setOnAction(event -> primaryStage.setScene(new Scene(flowPane11,450,300)));
        interfaceDrink.buttonD5.setOnAction(event -> primaryStage.setScene(new Scene(flowPane11,450,300)));
        primaryStage.setScene(scene);
        primaryStage.show();


    }


    public static void main(String[] args) {

        launch(args);
    }

}











