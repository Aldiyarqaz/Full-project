package sample;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.io.FileInputStream;
import java.util.ArrayList;

class InterfacePizza{
    BorderPane borderPane;
    FlowPane pane;
    Button buttonC1, buttonC2, buttonC3, buttonC4, back;
    InterfacePizza() throws Exception{

        ArrayList<String> options = new ArrayList<>();

        pane = new FlowPane();
        pane.setPadding(new Insets(30,12,13,30));
        pane.setHgap(10);
        pane.setVgap(30);
        FileInputStream backgrou = new FileInputStream("burg.jpg");
        Image imageback = new Image(backgrou);
        BackgroundImage bi = new BackgroundImage(imageback,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        Background background = new Background(bi);
        FileInputStream fileInputStream = new FileInputStream("c1.png");
        FileInputStream fileInputStream1 = new FileInputStream("c2.png");
        FileInputStream fileInputStream2 = new FileInputStream("c3.png");
        FileInputStream fileInputStream3 = new FileInputStream("c4.png");

        Image image = new Image(fileInputStream);
        Image image1 = new Image(fileInputStream1);
        Image image2 = new Image(fileInputStream2);
        Image image3 = new Image(fileInputStream3);

        ImageView imageView = new ImageView(image);
        ImageView imageView1 = new ImageView(image1);
        ImageView imageView2 = new ImageView(image2);
        ImageView imageView3 = new ImageView(image3);


        HBox vBox = new HBox(10);
        borderPane = new BorderPane();

        borderPane.setBackground(background);
        borderPane.setTop(vBox);
        borderPane.setCenter(pane);
        back = new Button("<-");
        options.add("1500 тг");
        options.add("1600 тг");
        options.add("1500 тг");
        options.add("1700 тг");



        buttonC1 = new Button(options.get(0), imageView);
        buttonC2 = new Button(options.get(1), imageView1);
        buttonC3 = new Button(options.get(2), imageView2);
        buttonC4 = new Button(options.get(3), imageView3);



        vBox.getChildren().addAll(back);
        pane.getChildren().addAll(buttonC1, buttonC2, buttonC3,buttonC4);

//        }
    }
}
