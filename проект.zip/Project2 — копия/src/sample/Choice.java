package sample;

import java.util.ArrayList;

abstract class Choice{
    ArrayList<String> options = new ArrayList<>();
    abstract ArrayList<String> getOptions();

    abstract void setOptions(ArrayList<String> options);

}
