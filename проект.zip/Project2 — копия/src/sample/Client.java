package sample;

class Client{
    String name;
    String password;

    public Client(String name, String password){
        this.password = password;
        this.name = name;
    }

    public Client() {

    }

    String getName() {

        return name;
    }

    void setName(String name) {

        this.name = name;
    }

    String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
